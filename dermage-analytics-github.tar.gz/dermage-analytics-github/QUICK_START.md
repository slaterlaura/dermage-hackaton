# Quick Start - Deploy no GitHub Pages

## 1. Clonar ou Fazer Download

```bash
# Se já tem git configurado
git clone https://github.com/SEU_USUARIO/dermage-analytics.git
cd dermage-analytics
```

## 2. Instalar Dependências

```bash
pnpm install
# ou
npm install
```

## 3. Testar Localmente

```bash
pnpm run dev
```

Acesse `http://localhost:3000` no navegador.

## 4. Build para Produção

```bash
pnpm run build
```

Isso gera a pasta `dist/public` com os arquivos estáticos.

## 5. Fazer Push para GitHub

```bash
git add .
git commit -m "Deploy para GitHub Pages"
git push origin main
```

## 6. Ativar GitHub Pages

1. Vá em **Settings** do repositório
2. Clique em **Pages**
3. Source: "Deploy from a branch"
4. Branch: `main`, Pasta: `/(root)`
5. Clique em **Save**

## 7. Acessar o Site

Após 2-5 minutos:
```
https://SEU_USUARIO.github.io/dermage-analytics/
```

## Troubleshooting

**Estilos não carregam?**
- Verifique se `base: '/dermage-analytics/'` está em `vite.config.ts`

**Imagens não aparecem?**
- Todas devem ser URLs absolutas (CDN), não caminhos locais

**Build falha?**
- Rode `pnpm install` novamente
- Verifique se Node.js 18+ está instalado

Para mais detalhes, veja `GITHUB_PAGES_DEPLOY.md`
