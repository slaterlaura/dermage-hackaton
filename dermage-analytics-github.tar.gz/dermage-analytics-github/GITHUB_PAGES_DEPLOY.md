# Guia de Deploy - Dermage Analytics no GitHub Pages

## Pré-requisitos

- Conta no GitHub
- Git instalado localmente
- Node.js 18+ e pnpm instalados

## Passo 1: Preparar o Repositório

### 1.1 Criar repositório no GitHub

1. Acesse [github.com/new](https://github.com/new)
2. Nome do repositório: `dermage-analytics` (ou outro nome de sua preferência)
3. Descrição: "Análise Estratégica de Recompra e Segmentação de Clientes Dermage"
4. Escolha: **Public** (necessário para GitHub Pages gratuito)
5. Clique em "Create repository"

### 1.2 Clonar e configurar localmente

```bash
# Clone o repositório vazio
git clone https://github.com/SEU_USUARIO/dermage-analytics.git
cd dermage-analytics

# Copie os arquivos do projeto
cp -r /home/ubuntu/dermage_analytics/* .

# Instale as dependências
pnpm install
```

## Passo 2: Configurar para GitHub Pages

### 2.1 Atualizar vite.config.ts

Adicione a configuração de base URL para GitHub Pages. Edite `vite.config.ts`:

```typescript
export default defineConfig({
  // ... resto da configuração ...
  base: '/dermage-analytics/', // Adicione esta linha
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true,
  },
  // ... resto da configuração ...
});
```

**Nota:** Se usar um domínio customizado, altere `base: '/'`

### 2.2 Atualizar package.json

Adicione script de deploy. Edite `package.json`:

```json
{
  "scripts": {
    "dev": "vite --host",
    "build": "vite build",
    "preview": "vite preview --host",
    "check": "tsc --noEmit",
    "deploy": "npm run build && git add dist -f && git commit -m 'Deploy to GitHub Pages' && git push"
  }
}
```

### 2.3 Criar arquivo .gitignore atualizado

Crie `.gitignore` na raiz do projeto:

```
node_modules/
dist/
.env
.env.local
.DS_Store
*.log
.manus-logs/
```

**Importante:** Remova `dist/` do .gitignore para que o build seja commitado

## Passo 3: Build e Deploy

### 3.1 Build local

```bash
# Instale dependências
pnpm install

# Faça o build
pnpm run build

# Verifique se foi criado dist/public
ls -la dist/public/
```

### 3.2 Commit e push

```bash
# Adicione todos os arquivos
git add .

# Commit inicial
git commit -m "Initial commit: Dermage Analytics"

# Push para main
git push origin main
```

### 3.3 Configurar GitHub Pages

1. Acesse **Settings** do repositório
2. Vá para **Pages** (na barra lateral esquerda)
3. Em "Build and deployment":
   - **Source:** Selecione "Deploy from a branch"
   - **Branch:** Selecione `main` e pasta `/(root)`
4. Clique em "Save"

GitHub Pages começará a fazer o build automaticamente.

## Passo 4: Configurar Deploy Automático (Opcional)

Para fazer deploy automático a cada push, crie `.github/workflows/deploy.yml`:

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        cache: 'pnpm'
    
    - name: Install pnpm
      run: npm install -g pnpm
    
    - name: Install dependencies
      run: pnpm install
    
    - name: Build
      run: pnpm run build
    
    - name: Deploy
      uses: peaceiris/actions-gh-pages@v3
      with:
        github_token: ${{ secrets.GITHUB_TOKEN }}
        publish_dir: ./dist/public
        cname: seu-dominio.com  # Remova esta linha se não usar domínio customizado
```

## Passo 5: Acessar o Site

Após alguns minutos, seu site estará disponível em:

```
https://SEU_USUARIO.github.io/dermage-analytics/
```

## Troubleshooting

### Site não aparece após 5 minutos

1. Verifique se o repositório é **Public**
2. Vá em **Settings > Pages** e confirme a configuração
3. Verifique se o build foi bem-sucedido em **Actions**

### Estilos não carregam

Certifique-se de que `base: '/dermage-analytics/'` está configurado em `vite.config.ts`

### Imagens não aparecem

Verifique se as URLs das imagens em `client/src/pages/Home.tsx` são URLs absolutas (CDN) e não caminhos relativos locais.

## Atualizar o Site

Para fazer novas atualizações:

```bash
# Faça as mudanças no código

# Build
pnpm run build

# Commit e push
git add .
git commit -m "Descrição das mudanças"
git push origin main

# GitHub Actions fará o deploy automaticamente (se configurado)
```

## Usar Domínio Customizado (Opcional)

Se tiver um domínio customizado:

1. Em **Settings > Pages**, adicione o domínio em "Custom domain"
2. Crie um arquivo `CNAME` na raiz com seu domínio:
   ```
   seu-dominio.com
   ```
3. Configure os DNS records do seu domínio apontando para GitHub Pages

## Estrutura Final do Projeto

```
dermage-analytics/
├── client/
│   ├── public/
│   ├── src/
│   │   ├── pages/
│   │   ├── components/
│   │   ├── App.tsx
│   │   ├── main.tsx
│   │   └── index.css
│   └── index.html
├── server/
├── shared/
├── .github/
│   └── workflows/
│       └── deploy.yml
├── vite.config.ts
├── package.json
├── tsconfig.json
└── README.md
```

## Suporte

Para mais informações sobre GitHub Pages:
- [Documentação Oficial](https://docs.github.com/en/pages)
- [Vite Deployment Guide](https://vitejs.dev/guide/static-deploy.html#github-pages)
