# Dermage Analytics - Análise de Recompra e Segmentação de Clientes

Análise estratégica completa do comportamento de recompra da Dermage com visualizações interativas e recomendações acionáveis.

## Funcionalidades

- **Análise de Recompra**: Taxa de recompra, tempo médio entre compras, período crítico
- **Segmentação de Clientes**: One-time, Occasional, Regular, Loyal
- **Análise de Produtos**: Porta de entrada, jornada de compra, top produtos
- **Sazonalidade**: Padrões mensais de compra e recompra
- **Canal e Região**: Performance por canal de venda e região geográfica
- **Recomendações**: 6 ações estratégicas com impacto estimado

## Stack Tecnológico

- React 19 + TypeScript
- Tailwind CSS 4
- Vite (build tool)
- Recharts (visualizações)
- shadcn/ui (componentes)

## Deploy Local

### Pré-requisitos

- Node.js 18+
- pnpm (ou npm/yarn)

### Instalação e Execução

```bash
# Instalar dependências
pnpm install

# Rodar em desenvolvimento
pnpm run dev

# Build para produção
pnpm run build

# Preview do build
pnpm run preview
```

O site estará disponível em `http://localhost:3000`

## Deploy no GitHub Pages

### Passo 1: Criar Repositório

1. Acesse [github.com/new](https://github.com/new)
2. Nome: `dermage-analytics`
3. Escolha **Public**
4. Clique em "Create repository"

### Passo 2: Fazer Push

```bash
# Inicializar git
git init
git add .
git commit -m "Initial commit: Dermage Analytics"

# Adicionar remote (substitua SEU_USUARIO)
git remote add origin https://github.com/SEU_USUARIO/dermage-analytics.git
git branch -M main
git push -u origin main
```

### Passo 3: Ativar GitHub Pages

1. Vá em **Settings** do repositório
2. Clique em **Pages** (barra lateral)
3. Em "Build and deployment":
   - Source: "Deploy from a branch"
   - Branch: `main`
   - Pasta: `/(root)`
4. Clique em "Save"

### Passo 4: Acessar o Site

Após 2-5 minutos, seu site estará em:
```
https://SEU_USUARIO.github.io/dermage-analytics/
```

## Estrutura do Projeto

```
dermage-analytics/
├── client/
│   ├── public/          # Arquivos estáticos (favicon, etc)
│   ├── src/
│   │   ├── pages/       # Páginas da aplicação
│   │   ├── components/  # Componentes React reutilizáveis
│   │   ├── App.tsx      # Componente raiz
│   │   ├── main.tsx     # Entry point
│   │   └── index.css    # Estilos globais
│   └── index.html       # HTML template
├── .github/
│   └── workflows/       # GitHub Actions (deploy automático)
├── vite.config.ts       # Configuração Vite
├── package.json         # Dependências
└── README.md            # Este arquivo
```

## Configuração para GitHub Pages

O projeto está pré-configurado para GitHub Pages:

- `vite.config.ts`: Base URL definida como `/dermage-analytics/`
- `package.json`: Scripts otimizados para build estático
- `.github/workflows/deploy.yml`: Deploy automático ao fazer push

## Troubleshooting

### Site não aparece após 5 minutos

- Verifique se o repositório é **Public**
- Vá em Settings > Pages e confirme a configuração
- Verifique os logs em Actions

### Estilos não carregam

- Confirme que `base: '/dermage-analytics/'` está em `vite.config.ts`
- Limpe o cache do navegador (Ctrl+Shift+Delete)

### Imagens não aparecem

- Todas as imagens devem ser URLs absolutas (CDN)
- Não use caminhos relativos locais

## Scripts Disponíveis

```bash
pnpm run dev      # Desenvolvimento com hot reload
pnpm run build    # Build para produção
pnpm run preview  # Preview do build
pnpm run check    # Type checking
pnpm run format   # Formatar código
```

## Análise Python

Para executar a análise completa dos dados:

```bash
cd /caminho/dos/dados
python3.11 analise_dermage_completa.py
```

Gera:
- `resumo_analise.json` - KPIs executivos
- `compras_cliente.csv` - Dados por cliente
- `pedidos_processados.csv` - Pedidos com features
- `recomendacoes.json` - 6 recomendações acionáveis

## Próximos Passos

1. **Implementar filtros interativos** - Permitir filtrar por período, região, segmento
2. **Adicionar export em PDF** - Gerar relatório completo para download
3. **Integrar dados em tempo real** - Conectar com banco de dados para atualizações automáticas
4. **Dashboard de KPIs** - Adicionar métricas atualizáveis

## Licença

MIT

## Contato

Para dúvidas sobre a análise ou deploy, consulte `GITHUB_PAGES_DEPLOY.md`
